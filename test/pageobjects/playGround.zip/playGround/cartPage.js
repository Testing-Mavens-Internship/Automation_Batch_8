import basePage from "./commonPage.js";

class cartPage extends basePage {
    constructor() {
        super()
        this.$header=()=>$('//h1[normalize-space()="Cart"]')
        this.$$incrementButton=()=>$$('//span[normalize-space()="+"]')
    }

    async clickIncrement() {
        for (let i in this.$$incrementButton()) {
        await this.$$incrementButton()[i].click()
        }
    }
        

}

export default new cartPage()